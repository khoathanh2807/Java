
public class Turtle extends Animal{

	private boolean seaTurtle;
	
	public Turtle() {
		super();
	}

	public Turtle(boolean seaTurtle, int legs) {
		super(legs);
		this.seaTurtle = seaTurtle;
	}
	
	public Turtle(Turtle tur) {
		super(tur.legs);
		this.seaTurtle = tur.seaTurtle;
	}

	@Override
	public void move() {
		System.out.println("Turtle is running");
	}

	@Override
	public String toString() {
		return "Turtle [seaTurtle=" + seaTurtle + ", legs=" + legs + "]";
	}

}
