
public class Rabbit extends Animal {
	
	private double speed;

	public Rabbit() {
		super();
	}

	Rabbit(Rabbit ra) {
		super(ra.legs);
		this.speed = ra.speed;
	}

	public Rabbit(double speed, int legs) {
		super(legs);
		this.speed = speed;
	}

	@Override
	public void move() {
		System.out.println("Rabbit is running");
	}

	@Override
	public String toString() {
		return "Rabbit [speed=" + speed + ", legs=" + legs + "]";
	}

}
