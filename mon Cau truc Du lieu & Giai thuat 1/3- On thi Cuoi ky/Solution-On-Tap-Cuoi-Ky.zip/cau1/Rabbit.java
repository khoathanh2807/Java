
public class Rabbit implements Animal {
	private double speed;

	public Rabbit() {
	}

	public Rabbit(Rabbit ra) {
		this.speed = ra.speed;
	}

	public Rabbit(double speed) {
		this.speed = speed;
	}

	@Override
	public void move() {
		System.out.println("Rabbit is running");
	}

	@Override
	public String toString() {
		return "Rabbit [speed=" + speed + "]";
	}

}
