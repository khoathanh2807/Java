
public class Turtle implements Animal{

	private boolean seaTurtle;
	
	public Turtle() {
	}

	public Turtle(boolean seaTurtle) {
		this.seaTurtle = seaTurtle;
	}
	
	public Turtle(Turtle turtle) {
		this.seaTurtle = turtle.seaTurtle;
	}

	@Override
	public void move() {
		System.out.println("Turtle is running");
	}

	@Override
	public String toString() {
		return "Turtle [seaTurtle=" + seaTurtle + "]";
	}

}
